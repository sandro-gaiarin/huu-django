from django.shortcuts import render
from django.http import HttpResponse
from .models import CodeRoom

# Create your views here.

coderooms = [ 
    {'id' : 1, 'name': 'Gameboy code'},
    {'id' : 2, 'name': 'Gameboy code2'},
    {'id' : 3, 'name': 'Gameboy code3'},
]

def home(request):
    coderooms = CodeRoom.objects.all()
    context = {'coderooms': coderooms}
    return render(request, 'base/home.html',context)

def coderoom(request, pk):
    coderoom = CodeRoom.objects.get(id= pk)
    context = {'coderoom':coderoom}
    return render(request, 'base/coderoom.html', context)

